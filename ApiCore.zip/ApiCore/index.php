<?php


$url="";
if(isset($_GET["URL"])){$url=$_GET["URL"];}


$FileList = [];
//echo is_dir("songs");
if (is_dir("songs"))
{
    if ($dh = opendir("songs")){
        while (($file = readdir($dh)) !== false) {
            if($file=="." || $file=="..")continue;
                array_push( $FileList, $file);
        }
        closedir($dh);
    }
}


?>


<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no">
    <title>Online_Player</title>
    <link rel="stylesheet" href="assets/bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/fonts/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/styles.css">
    <script src="assets/js/jquery.min.js"></script>
    <script>

        $("#URL").val();
        function PlayUrl() {
            var url = $("#URL").val();
            $("#AudioPlayer").attr("src", url);

        }
       
    </script>
</head>

<body style="background: rgb(251,251,251);">
    <nav class="navbar navbar-dark navbar-expand-md bg-dark shadow-sm">
        <div class="container"><a class="navbar-brand" href="#">Online Song Player</a></div>
    </nav>
    <div class="container" style="margin-top: 10px;">
        <h5 class="text-secondary">Select From List</h5>
    </div>
    <hr>
    <div class="container" style="margin-top: 10px;">
        <div class="row">
            <div class="col">
                <ul class="list-group">
                    <?php foreach($FileList as $file) { ?>
                    <a href="index.php?URL=http://bhumi30-001-site1.itempurl.com/songs/<?php echo $file; ?>">
                        <li class="list-group-item">
                            <span>
                                <?php echo $file; ?>
                            </span>
                        </li>
                    </a>

                    <?php }?>

                </ul>

            </div>
            <div class="col">
                <div class="card">
                    <div class="card-body shadow-sm">
                        <h4 class="text-danger card-title">Player</h4>
                        <hr>
                        <h6 class="text-secondary card-title">Play Url</h6>
                        <form>
                            <div class="input-group">
                                <input class="form-control" type="text" id="URL" name="URL" value="<?php echo $url; ?>" placeholder="Enter Song Url here" />
                                <div class="input-group-append">
                                    <button class="btn btn-success" type="submit">
                                        <i class="fa fa-play"></i>
                                    </button>
                                </div>
                            </div>
                        </form>
                        <audio controls="" style="width: 100%;">
                        <source id="AudioPlayer" src="<?php echo $url; ?>" type="audio/mpeg"></audio>
                        <p class="lead text-secondary card-text">Playing - <?php echo $url; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="assets/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>